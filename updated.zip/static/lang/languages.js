export default [
  {
    code: 'en',
    iso: 'en-US',
    name: 'English',
    file: 'en-US.js',
    dir: 'ltr'
  },
  {
    code: 'id',
    iso: 'id-ID',
    name: 'Bahasa Indonesia',
    file: 'id-ID.js',
    dir: 'ltr'
  }
]
