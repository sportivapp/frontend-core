export default {"theme":{"light":true,"themes":{"light":{"primary":"#FF7041"}}}}
