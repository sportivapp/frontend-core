const middleware = {}

middleware['not-authenticated'] = require('..\\middleware\\not-authenticated.js')
middleware['not-authenticated'] = middleware['not-authenticated'].default || middleware['not-authenticated']

export default middleware
