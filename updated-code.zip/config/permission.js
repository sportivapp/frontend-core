const permissions = {
  create: 'C',
  read: 'R',
  update: 'U',
  delete: 'D'
}

export {
  permissions
}
