export { default as AddBankAccountModal } from '../..\\components\\BankAccount\\AddBankAccountModal.vue'
export { default as BankAccountCard } from '../..\\components\\BankAccount\\BankAccountCard.vue'
export { default as BankAccountList } from '../..\\components\\BankAccount\\BankAccountList.vue'
export { default as ValidationBankAccountMixin } from '../..\\components\\BankAccount\\validationBankAccount.mixin.js'
export { default as AboutBg } from '../..\\components\\About\\AboutBg.vue'
export { default as AboutInfo } from '../..\\components\\About\\AboutInfo.vue'
export { default as Feature } from '../..\\components\\About\\Feature.vue'
export { default as VisiMisi } from '../..\\components\\About\\VisiMisi.vue'
export { default as SimpleBreadcrumb } from '../..\\components\\Breadcrumb\\SimpleBreadcrumb.vue'
export { default as LoginRegisterBg } from '../..\\components\\Backgrounds\\LoginRegisterBg.vue'
export { default as PageNotFound } from '../..\\components\\Backgrounds\\PageNotFound.vue'
export { default as UnderConstruction } from '../..\\components\\Backgrounds\\UnderConstruction.vue'
export { default as UnderConstructionPage } from '../..\\components\\Backgrounds\\UnderConstructionPage.vue'
export { default as LeftIconCard } from '../..\\components\\Card\\LeftIconCard.vue'
export { default as TextInfoHeader } from '../..\\components\\Card\\TextInfoHeader.vue'
export { default as ClassList } from '../..\\components\\Class\\ClassList.vue'
export { default as ValidationMixin } from '../..\\components\\Class\\validation.mixin.js'
export { default as ValidationCategoryMixin } from '../..\\components\\Class\\validationCategory.mixin.js'
export { default as ValidationExtendMixin } from '../..\\components\\Class\\validationExtend.mixin.js'
export { default as ContactList } from '../..\\components\\ContactUs\\contactList.vue'
export { default as SearchBar } from '../..\\components\\inputs\\SearchBar.vue'
export { default as ShowMoreButton } from '../..\\components\\inputs\\ShowMoreButton.vue'
export { default as HomeFooter } from '../..\\components\\Footer\\HomeFooter.vue'
export { default as TranslateBox } from '../..\\components\\Footer\\TranslateBox.vue'
export { default as LegalTabs } from '../..\\components\\Legal\\LegalTabs.vue'
export { default as LineupMemberCard } from '../..\\components\\MatchInfo\\LineupMemberCard.vue'
export { default as LineupTable } from '../..\\components\\MatchInfo\\LineupTable.vue'
export { default as MatchInfoCard } from '../..\\components\\MatchInfo\\MatchInfoCard.vue'
export { default as MemberStatisticCard } from '../..\\components\\MatchInfo\\MemberStatisticCard.vue'
export { default as SimplePrompt } from '../..\\components\\Modal\\SimplePrompt.vue'
export { default as TournamentMenu } from '../..\\components\\Navigation\\TournamentMenu.vue'
export { default as UserMenu } from '../..\\components\\Navigation\\UserMenu.vue'
export { default as AuthorSummary } from '../..\\components\\News\\AuthorSummary.vue'
export { default as HomeNews } from '../..\\components\\News\\HomeNews.vue'
export { default as LargeNewsTile } from '../..\\components\\News\\LargeNewsTile.vue'
export { default as LongNewsTile } from '../..\\components\\News\\LongNewsTile.vue'
export { default as NewsCarousel } from '../..\\components\\News\\NewsCarousel.vue'
export { default as NewsCategoryFilter } from '../..\\components\\News\\NewsCategoryFilter.vue'
export { default as NewsDetailContent } from '../..\\components\\News\\NewsDetailContent.vue'
export { default as NewsHeadline } from '../..\\components\\News\\NewsHeadline.vue'
export { default as NewsList } from '../..\\components\\News\\NewsList.vue'
export { default as NewsPageBottomList } from '../..\\components\\News\\NewsPageBottomList.vue'
export { default as NewsTile } from '../..\\components\\News\\NewsTile.vue'
export { default as RelatedNews } from '../..\\components\\News\\RelatedNews.vue'
export { default as SideNews } from '../..\\components\\News\\SideNews.vue'
export { default as HomeOrganizationV1 } from '../..\\components\\Organization\\HomeOrganizationV1.vue'
export { default as HomeOrganizationV2 } from '../..\\components\\Organization\\HomeOrganizationV2.vue'
export { default as OrganizationCarousel } from '../..\\components\\Organization\\OrganizationCarousel.vue'
export { default as EmptyTemplate } from '../..\\components\\Others\\EmptyTemplate.vue'
export { default as RegisterOtp } from '../..\\components\\Register\\RegisterOTP.vue'
export { default as RegisterUser } from '../..\\components\\Register\\RegisterUser.vue'
export { default as ResetPasswordForm } from '../..\\components\\ResetPassword\\ResetPasswordForm.vue'
export { default as SimpleSnackBar } from '../..\\components\\SnackBar\\SimpleSnackBar.vue'
export { default as Editor } from '../..\\components\\TextEditor\\Editor.vue'
export { default as HomeTournament } from '../..\\components\\Tournament\\HomeTournament.vue'
export { default as LargeTournamentTile } from '../..\\components\\Tournament\\LargeTournamentTile.vue'
export { default as TournamentCarousel } from '../..\\components\\Tournament\\TournamentCarousel.vue'
export { default as TournamentHeadline } from '../..\\components\\Tournament\\TournamentHeadline.vue'
export { default as TournamentList } from '../..\\components\\Tournament\\TournamentList.vue'
export { default as TournamentPageBottomList } from '../..\\components\\Tournament\\TournamentPageBottomList.vue'
export { default as TournamentTile } from '../..\\components\\Tournament\\TournamentTile.vue'
export { default as MatchGroup } from '../..\\components\\TournamentDetail\\MatchGroup.vue'
export { default as MatchList } from '../..\\components\\TournamentDetail\\MatchList.vue'
export { default as MatchTile } from '../..\\components\\TournamentDetail\\MatchTile.vue'
export { default as MatchTileParticipantRow } from '../..\\components\\TournamentDetail\\MatchTileParticipantRow.vue'
export { default as OtherTournaments } from '../..\\components\\TournamentDetail\\OtherTournaments.vue'
export { default as RoundList } from '../..\\components\\TournamentDetail\\RoundList.vue'
export { default as TournamentDetailHeader } from '../..\\components\\TournamentDetail\\TournamentDetailHeader.vue'
export { default as TournamentDetailInfo } from '../..\\components\\TournamentDetail\\TournamentDetailInfo.vue'
export { default as BannerCarouselV1 } from '../..\\components\\Banners\\HomeTopBanner\\BannerCarouselV1.vue'
export { default as BannerCarouselV2 } from '../..\\components\\Banners\\HomeTopBanner\\BannerCarouselV2.vue'
export { default as HomeTopBanner } from '../..\\components\\Banners\\HomeTopBanner\\HomeTopBanner.vue'
export { default as CategoryCoachList } from '../..\\components\\Class\\Category\\CategoryCoachList.vue'
export { default as CategoryCoachListItem } from '../..\\components\\Class\\Category\\CategoryCoachListItem.vue'
export { default as CategoryLandingScheduleList } from '../..\\components\\Class\\Category\\CategoryLandingScheduleList.vue'
export { default as CategoryLandingScheduleListItem } from '../..\\components\\Class\\Category\\CategoryLandingScheduleListItem.vue'
export { default as CategoryScheduleList } from '../..\\components\\Class\\Category\\CategoryScheduleList.vue'
export { default as CategoryScheduleListItem } from '../..\\components\\Class\\Category\\CategoryScheduleListItem.vue'
export { default as ClassCategoryModal } from '../..\\components\\Class\\Category\\ClassCategoryModal.vue'
export { default as ClassCategoryTable } from '../..\\components\\Class\\Category\\ClassCategoryTable.vue'
export { default as ClassCategoryTableRow } from '../..\\components\\Class\\Category\\ClassCategoryTableRow.vue'
export { default as ClassLandingCategoryModal } from '../..\\components\\Class\\Category\\ClassLandingCategoryModal.vue'
export { default as ClassLandingCategoryRow } from '../..\\components\\Class\\Category\\ClassLandingCategoryRow.vue'
export { default as ClassLandingCategoryTable } from '../..\\components\\Class\\Category\\ClassLandingCategoryTable.vue'
export { default as PreviewSessionList } from '../..\\components\\Class\\Category\\PreviewSessionList.vue'
export { default as ClassCategoryDetail } from '../..\\components\\Class\\ClassCategory\\ClassCategoryDetail.vue'
export { default as ClassCategoryHistory } from '../..\\components\\Class\\ClassCategory\\ClassCategoryHistory.vue'
export { default as ClassCategoryInfo } from '../..\\components\\Class\\ClassCategory\\ClassCategoryInfo.vue'
export { default as ClassCategorySession } from '../..\\components\\Class\\ClassCategory\\ClassCategorySession.vue'
export { default as ClassCategorySessionDialog } from '../..\\components\\Class\\ClassCategory\\ClassCategorySessionDialog.vue'
export { default as ClassCategorySessionRow } from '../..\\components\\Class\\ClassCategory\\ClassCategorySessionRow.vue'
export { default as ClassInfo } from '../..\\components\\Class\\ClassDetail\\ClassInfo.vue'
export { default as ClassParticipants } from '../..\\components\\Class\\ClassDetail\\ClassParticipants.vue'
export { default as ClassParticipantsTable } from '../..\\components\\Class\\ClassDetail\\ClassParticipantsTable.vue'
export { default as AddCoachModal } from '../..\\components\\Class\\CreateClass\\AddCoachModal.vue'
export { default as ClassForm } from '../..\\components\\Class\\CreateClass\\ClassForm.vue'
export { default as CoachTable } from '../..\\components\\Class\\CreateClass\\CoachTable.vue'
export { default as CoachTile } from '../..\\components\\Class\\CreateClass\\CoachTile.vue'
export { default as FileContainer } from '../..\\components\\Class\\CreateClass\\FileContainer.vue'
export { default as UploadFileNew } from '../..\\components\\Class\\CreateClass\\UploadFileNew.vue'
export { default as SportivButton } from '../..\\components\\inputs\\SportivButton\\SportivButton.vue'
export { default as SeeAllButton } from '../..\\components\\Navigation\\SeeAllButton\\SeeAllButton.vue'
export { default as CreateOrganization } from '../..\\components\\Organization\\Create\\CreateOrganization.vue'
export { default as ViewMyOrganization } from '../..\\components\\Organization\\View\\ViewMyOrganization.vue'
export { default as StandingTable } from '../..\\components\\Tables\\StandingTable\\StandingTable.vue'
export { default as StandingTableRow } from '../..\\components\\Tables\\StandingTable\\StandingTableRow.vue'
export { default as TournamentAllParticipant } from '../..\\components\\TournamentDetail\\TournamentParticipant\\TournamentAllParticipant.vue'
export { default as TournamentParticipantTable } from '../..\\components\\TournamentDetail\\TournamentParticipant\\TournamentParticipantTable.vue'
export { default as TournamentStageParticipantTable } from '../..\\components\\TournamentDetail\\TournamentParticipant\\TournamentStageParticipantTable.vue'
export { default as TournamentStage } from '../..\\components\\TournamentDetail\\TournamentStage\\TournamentStage.vue'
export { default as TournamentStageMatch } from '../..\\components\\TournamentDetail\\TournamentStage\\TournamentStageMatch.vue'
export { default as TournamentStageParticipant } from '../..\\components\\TournamentDetail\\TournamentStage\\TournamentStageParticipant.vue'
export { default as TournamentStageStanding } from '../..\\components\\TournamentDetail\\TournamentStage\\TournamentStageStanding.vue'
export { default as UpdateScheduleModal } from '../..\\components\\Class\\ClassCategory\\Modal\\UpdateScheduleModal.vue'
export { default as ViewReviewModal } from '../..\\components\\Class\\ClassCategory\\Modal\\ViewReviewModal.vue'

export const LazyAddBankAccountModal = import('../..\\components\\BankAccount\\AddBankAccountModal.vue' /* webpackChunkName: "components_BankAccount/AddBankAccountModal" */).then(c => c.default || c)
export const LazyBankAccountCard = import('../..\\components\\BankAccount\\BankAccountCard.vue' /* webpackChunkName: "components_BankAccount/BankAccountCard" */).then(c => c.default || c)
export const LazyBankAccountList = import('../..\\components\\BankAccount\\BankAccountList.vue' /* webpackChunkName: "components_BankAccount/BankAccountList" */).then(c => c.default || c)
export const LazyValidationBankAccountMixin = import('../..\\components\\BankAccount\\validationBankAccount.mixin.js' /* webpackChunkName: "components_BankAccount/validationBankAccount.mixin" */).then(c => c.default || c)
export const LazyAboutBg = import('../..\\components\\About\\AboutBg.vue' /* webpackChunkName: "components_About/AboutBg" */).then(c => c.default || c)
export const LazyAboutInfo = import('../..\\components\\About\\AboutInfo.vue' /* webpackChunkName: "components_About/AboutInfo" */).then(c => c.default || c)
export const LazyFeature = import('../..\\components\\About\\Feature.vue' /* webpackChunkName: "components_About/Feature" */).then(c => c.default || c)
export const LazyVisiMisi = import('../..\\components\\About\\VisiMisi.vue' /* webpackChunkName: "components_About/VisiMisi" */).then(c => c.default || c)
export const LazySimpleBreadcrumb = import('../..\\components\\Breadcrumb\\SimpleBreadcrumb.vue' /* webpackChunkName: "components_Breadcrumb/SimpleBreadcrumb" */).then(c => c.default || c)
export const LazyLoginRegisterBg = import('../..\\components\\Backgrounds\\LoginRegisterBg.vue' /* webpackChunkName: "components_Backgrounds/LoginRegisterBg" */).then(c => c.default || c)
export const LazyPageNotFound = import('../..\\components\\Backgrounds\\PageNotFound.vue' /* webpackChunkName: "components_Backgrounds/PageNotFound" */).then(c => c.default || c)
export const LazyUnderConstruction = import('../..\\components\\Backgrounds\\UnderConstruction.vue' /* webpackChunkName: "components_Backgrounds/UnderConstruction" */).then(c => c.default || c)
export const LazyUnderConstructionPage = import('../..\\components\\Backgrounds\\UnderConstructionPage.vue' /* webpackChunkName: "components_Backgrounds/UnderConstructionPage" */).then(c => c.default || c)
export const LazyLeftIconCard = import('../..\\components\\Card\\LeftIconCard.vue' /* webpackChunkName: "components_Card/LeftIconCard" */).then(c => c.default || c)
export const LazyTextInfoHeader = import('../..\\components\\Card\\TextInfoHeader.vue' /* webpackChunkName: "components_Card/TextInfoHeader" */).then(c => c.default || c)
export const LazyClassList = import('../..\\components\\Class\\ClassList.vue' /* webpackChunkName: "components_Class/ClassList" */).then(c => c.default || c)
export const LazyValidationMixin = import('../..\\components\\Class\\validation.mixin.js' /* webpackChunkName: "components_Class/validation.mixin" */).then(c => c.default || c)
export const LazyValidationCategoryMixin = import('../..\\components\\Class\\validationCategory.mixin.js' /* webpackChunkName: "components_Class/validationCategory.mixin" */).then(c => c.default || c)
export const LazyValidationExtendMixin = import('../..\\components\\Class\\validationExtend.mixin.js' /* webpackChunkName: "components_Class/validationExtend.mixin" */).then(c => c.default || c)
export const LazyContactList = import('../..\\components\\ContactUs\\contactList.vue' /* webpackChunkName: "components_ContactUs/contactList" */).then(c => c.default || c)
export const LazySearchBar = import('../..\\components\\inputs\\SearchBar.vue' /* webpackChunkName: "components_inputs/SearchBar" */).then(c => c.default || c)
export const LazyShowMoreButton = import('../..\\components\\inputs\\ShowMoreButton.vue' /* webpackChunkName: "components_inputs/ShowMoreButton" */).then(c => c.default || c)
export const LazyHomeFooter = import('../..\\components\\Footer\\HomeFooter.vue' /* webpackChunkName: "components_Footer/HomeFooter" */).then(c => c.default || c)
export const LazyTranslateBox = import('../..\\components\\Footer\\TranslateBox.vue' /* webpackChunkName: "components_Footer/TranslateBox" */).then(c => c.default || c)
export const LazyLegalTabs = import('../..\\components\\Legal\\LegalTabs.vue' /* webpackChunkName: "components_Legal/LegalTabs" */).then(c => c.default || c)
export const LazyLineupMemberCard = import('../..\\components\\MatchInfo\\LineupMemberCard.vue' /* webpackChunkName: "components_MatchInfo/LineupMemberCard" */).then(c => c.default || c)
export const LazyLineupTable = import('../..\\components\\MatchInfo\\LineupTable.vue' /* webpackChunkName: "components_MatchInfo/LineupTable" */).then(c => c.default || c)
export const LazyMatchInfoCard = import('../..\\components\\MatchInfo\\MatchInfoCard.vue' /* webpackChunkName: "components_MatchInfo/MatchInfoCard" */).then(c => c.default || c)
export const LazyMemberStatisticCard = import('../..\\components\\MatchInfo\\MemberStatisticCard.vue' /* webpackChunkName: "components_MatchInfo/MemberStatisticCard" */).then(c => c.default || c)
export const LazySimplePrompt = import('../..\\components\\Modal\\SimplePrompt.vue' /* webpackChunkName: "components_Modal/SimplePrompt" */).then(c => c.default || c)
export const LazyTournamentMenu = import('../..\\components\\Navigation\\TournamentMenu.vue' /* webpackChunkName: "components_Navigation/TournamentMenu" */).then(c => c.default || c)
export const LazyUserMenu = import('../..\\components\\Navigation\\UserMenu.vue' /* webpackChunkName: "components_Navigation/UserMenu" */).then(c => c.default || c)
export const LazyAuthorSummary = import('../..\\components\\News\\AuthorSummary.vue' /* webpackChunkName: "components_News/AuthorSummary" */).then(c => c.default || c)
export const LazyHomeNews = import('../..\\components\\News\\HomeNews.vue' /* webpackChunkName: "components_News/HomeNews" */).then(c => c.default || c)
export const LazyLargeNewsTile = import('../..\\components\\News\\LargeNewsTile.vue' /* webpackChunkName: "components_News/LargeNewsTile" */).then(c => c.default || c)
export const LazyLongNewsTile = import('../..\\components\\News\\LongNewsTile.vue' /* webpackChunkName: "components_News/LongNewsTile" */).then(c => c.default || c)
export const LazyNewsCarousel = import('../..\\components\\News\\NewsCarousel.vue' /* webpackChunkName: "components_News/NewsCarousel" */).then(c => c.default || c)
export const LazyNewsCategoryFilter = import('../..\\components\\News\\NewsCategoryFilter.vue' /* webpackChunkName: "components_News/NewsCategoryFilter" */).then(c => c.default || c)
export const LazyNewsDetailContent = import('../..\\components\\News\\NewsDetailContent.vue' /* webpackChunkName: "components_News/NewsDetailContent" */).then(c => c.default || c)
export const LazyNewsHeadline = import('../..\\components\\News\\NewsHeadline.vue' /* webpackChunkName: "components_News/NewsHeadline" */).then(c => c.default || c)
export const LazyNewsList = import('../..\\components\\News\\NewsList.vue' /* webpackChunkName: "components_News/NewsList" */).then(c => c.default || c)
export const LazyNewsPageBottomList = import('../..\\components\\News\\NewsPageBottomList.vue' /* webpackChunkName: "components_News/NewsPageBottomList" */).then(c => c.default || c)
export const LazyNewsTile = import('../..\\components\\News\\NewsTile.vue' /* webpackChunkName: "components_News/NewsTile" */).then(c => c.default || c)
export const LazyRelatedNews = import('../..\\components\\News\\RelatedNews.vue' /* webpackChunkName: "components_News/RelatedNews" */).then(c => c.default || c)
export const LazySideNews = import('../..\\components\\News\\SideNews.vue' /* webpackChunkName: "components_News/SideNews" */).then(c => c.default || c)
export const LazyHomeOrganizationV1 = import('../..\\components\\Organization\\HomeOrganizationV1.vue' /* webpackChunkName: "components_Organization/HomeOrganizationV1" */).then(c => c.default || c)
export const LazyHomeOrganizationV2 = import('../..\\components\\Organization\\HomeOrganizationV2.vue' /* webpackChunkName: "components_Organization/HomeOrganizationV2" */).then(c => c.default || c)
export const LazyOrganizationCarousel = import('../..\\components\\Organization\\OrganizationCarousel.vue' /* webpackChunkName: "components_Organization/OrganizationCarousel" */).then(c => c.default || c)
export const LazyEmptyTemplate = import('../..\\components\\Others\\EmptyTemplate.vue' /* webpackChunkName: "components_Others/EmptyTemplate" */).then(c => c.default || c)
export const LazyRegisterOtp = import('../..\\components\\Register\\RegisterOTP.vue' /* webpackChunkName: "components_Register/RegisterOTP" */).then(c => c.default || c)
export const LazyRegisterUser = import('../..\\components\\Register\\RegisterUser.vue' /* webpackChunkName: "components_Register/RegisterUser" */).then(c => c.default || c)
export const LazyResetPasswordForm = import('../..\\components\\ResetPassword\\ResetPasswordForm.vue' /* webpackChunkName: "components_ResetPassword/ResetPasswordForm" */).then(c => c.default || c)
export const LazySimpleSnackBar = import('../..\\components\\SnackBar\\SimpleSnackBar.vue' /* webpackChunkName: "components_SnackBar/SimpleSnackBar" */).then(c => c.default || c)
export const LazyEditor = import('../..\\components\\TextEditor\\Editor.vue' /* webpackChunkName: "components_TextEditor/Editor" */).then(c => c.default || c)
export const LazyHomeTournament = import('../..\\components\\Tournament\\HomeTournament.vue' /* webpackChunkName: "components_Tournament/HomeTournament" */).then(c => c.default || c)
export const LazyLargeTournamentTile = import('../..\\components\\Tournament\\LargeTournamentTile.vue' /* webpackChunkName: "components_Tournament/LargeTournamentTile" */).then(c => c.default || c)
export const LazyTournamentCarousel = import('../..\\components\\Tournament\\TournamentCarousel.vue' /* webpackChunkName: "components_Tournament/TournamentCarousel" */).then(c => c.default || c)
export const LazyTournamentHeadline = import('../..\\components\\Tournament\\TournamentHeadline.vue' /* webpackChunkName: "components_Tournament/TournamentHeadline" */).then(c => c.default || c)
export const LazyTournamentList = import('../..\\components\\Tournament\\TournamentList.vue' /* webpackChunkName: "components_Tournament/TournamentList" */).then(c => c.default || c)
export const LazyTournamentPageBottomList = import('../..\\components\\Tournament\\TournamentPageBottomList.vue' /* webpackChunkName: "components_Tournament/TournamentPageBottomList" */).then(c => c.default || c)
export const LazyTournamentTile = import('../..\\components\\Tournament\\TournamentTile.vue' /* webpackChunkName: "components_Tournament/TournamentTile" */).then(c => c.default || c)
export const LazyMatchGroup = import('../..\\components\\TournamentDetail\\MatchGroup.vue' /* webpackChunkName: "components_TournamentDetail/MatchGroup" */).then(c => c.default || c)
export const LazyMatchList = import('../..\\components\\TournamentDetail\\MatchList.vue' /* webpackChunkName: "components_TournamentDetail/MatchList" */).then(c => c.default || c)
export const LazyMatchTile = import('../..\\components\\TournamentDetail\\MatchTile.vue' /* webpackChunkName: "components_TournamentDetail/MatchTile" */).then(c => c.default || c)
export const LazyMatchTileParticipantRow = import('../..\\components\\TournamentDetail\\MatchTileParticipantRow.vue' /* webpackChunkName: "components_TournamentDetail/MatchTileParticipantRow" */).then(c => c.default || c)
export const LazyOtherTournaments = import('../..\\components\\TournamentDetail\\OtherTournaments.vue' /* webpackChunkName: "components_TournamentDetail/OtherTournaments" */).then(c => c.default || c)
export const LazyRoundList = import('../..\\components\\TournamentDetail\\RoundList.vue' /* webpackChunkName: "components_TournamentDetail/RoundList" */).then(c => c.default || c)
export const LazyTournamentDetailHeader = import('../..\\components\\TournamentDetail\\TournamentDetailHeader.vue' /* webpackChunkName: "components_TournamentDetail/TournamentDetailHeader" */).then(c => c.default || c)
export const LazyTournamentDetailInfo = import('../..\\components\\TournamentDetail\\TournamentDetailInfo.vue' /* webpackChunkName: "components_TournamentDetail/TournamentDetailInfo" */).then(c => c.default || c)
export const LazyBannerCarouselV1 = import('../..\\components\\Banners\\HomeTopBanner\\BannerCarouselV1.vue' /* webpackChunkName: "components_Banners/HomeTopBanner/BannerCarouselV1" */).then(c => c.default || c)
export const LazyBannerCarouselV2 = import('../..\\components\\Banners\\HomeTopBanner\\BannerCarouselV2.vue' /* webpackChunkName: "components_Banners/HomeTopBanner/BannerCarouselV2" */).then(c => c.default || c)
export const LazyHomeTopBanner = import('../..\\components\\Banners\\HomeTopBanner\\HomeTopBanner.vue' /* webpackChunkName: "components_Banners/HomeTopBanner/HomeTopBanner" */).then(c => c.default || c)
export const LazyCategoryCoachList = import('../..\\components\\Class\\Category\\CategoryCoachList.vue' /* webpackChunkName: "components_Class/Category/CategoryCoachList" */).then(c => c.default || c)
export const LazyCategoryCoachListItem = import('../..\\components\\Class\\Category\\CategoryCoachListItem.vue' /* webpackChunkName: "components_Class/Category/CategoryCoachListItem" */).then(c => c.default || c)
export const LazyCategoryLandingScheduleList = import('../..\\components\\Class\\Category\\CategoryLandingScheduleList.vue' /* webpackChunkName: "components_Class/Category/CategoryLandingScheduleList" */).then(c => c.default || c)
export const LazyCategoryLandingScheduleListItem = import('../..\\components\\Class\\Category\\CategoryLandingScheduleListItem.vue' /* webpackChunkName: "components_Class/Category/CategoryLandingScheduleListItem" */).then(c => c.default || c)
export const LazyCategoryScheduleList = import('../..\\components\\Class\\Category\\CategoryScheduleList.vue' /* webpackChunkName: "components_Class/Category/CategoryScheduleList" */).then(c => c.default || c)
export const LazyCategoryScheduleListItem = import('../..\\components\\Class\\Category\\CategoryScheduleListItem.vue' /* webpackChunkName: "components_Class/Category/CategoryScheduleListItem" */).then(c => c.default || c)
export const LazyClassCategoryModal = import('../..\\components\\Class\\Category\\ClassCategoryModal.vue' /* webpackChunkName: "components_Class/Category/ClassCategoryModal" */).then(c => c.default || c)
export const LazyClassCategoryTable = import('../..\\components\\Class\\Category\\ClassCategoryTable.vue' /* webpackChunkName: "components_Class/Category/ClassCategoryTable" */).then(c => c.default || c)
export const LazyClassCategoryTableRow = import('../..\\components\\Class\\Category\\ClassCategoryTableRow.vue' /* webpackChunkName: "components_Class/Category/ClassCategoryTableRow" */).then(c => c.default || c)
export const LazyClassLandingCategoryModal = import('../..\\components\\Class\\Category\\ClassLandingCategoryModal.vue' /* webpackChunkName: "components_Class/Category/ClassLandingCategoryModal" */).then(c => c.default || c)
export const LazyClassLandingCategoryRow = import('../..\\components\\Class\\Category\\ClassLandingCategoryRow.vue' /* webpackChunkName: "components_Class/Category/ClassLandingCategoryRow" */).then(c => c.default || c)
export const LazyClassLandingCategoryTable = import('../..\\components\\Class\\Category\\ClassLandingCategoryTable.vue' /* webpackChunkName: "components_Class/Category/ClassLandingCategoryTable" */).then(c => c.default || c)
export const LazyPreviewSessionList = import('../..\\components\\Class\\Category\\PreviewSessionList.vue' /* webpackChunkName: "components_Class/Category/PreviewSessionList" */).then(c => c.default || c)
export const LazyClassCategoryDetail = import('../..\\components\\Class\\ClassCategory\\ClassCategoryDetail.vue' /* webpackChunkName: "components_Class/ClassCategory/ClassCategoryDetail" */).then(c => c.default || c)
export const LazyClassCategoryHistory = import('../..\\components\\Class\\ClassCategory\\ClassCategoryHistory.vue' /* webpackChunkName: "components_Class/ClassCategory/ClassCategoryHistory" */).then(c => c.default || c)
export const LazyClassCategoryInfo = import('../..\\components\\Class\\ClassCategory\\ClassCategoryInfo.vue' /* webpackChunkName: "components_Class/ClassCategory/ClassCategoryInfo" */).then(c => c.default || c)
export const LazyClassCategorySession = import('../..\\components\\Class\\ClassCategory\\ClassCategorySession.vue' /* webpackChunkName: "components_Class/ClassCategory/ClassCategorySession" */).then(c => c.default || c)
export const LazyClassCategorySessionDialog = import('../..\\components\\Class\\ClassCategory\\ClassCategorySessionDialog.vue' /* webpackChunkName: "components_Class/ClassCategory/ClassCategorySessionDialog" */).then(c => c.default || c)
export const LazyClassCategorySessionRow = import('../..\\components\\Class\\ClassCategory\\ClassCategorySessionRow.vue' /* webpackChunkName: "components_Class/ClassCategory/ClassCategorySessionRow" */).then(c => c.default || c)
export const LazyClassInfo = import('../..\\components\\Class\\ClassDetail\\ClassInfo.vue' /* webpackChunkName: "components_Class/ClassDetail/ClassInfo" */).then(c => c.default || c)
export const LazyClassParticipants = import('../..\\components\\Class\\ClassDetail\\ClassParticipants.vue' /* webpackChunkName: "components_Class/ClassDetail/ClassParticipants" */).then(c => c.default || c)
export const LazyClassParticipantsTable = import('../..\\components\\Class\\ClassDetail\\ClassParticipantsTable.vue' /* webpackChunkName: "components_Class/ClassDetail/ClassParticipantsTable" */).then(c => c.default || c)
export const LazyAddCoachModal = import('../..\\components\\Class\\CreateClass\\AddCoachModal.vue' /* webpackChunkName: "components_Class/CreateClass/AddCoachModal" */).then(c => c.default || c)
export const LazyClassForm = import('../..\\components\\Class\\CreateClass\\ClassForm.vue' /* webpackChunkName: "components_Class/CreateClass/ClassForm" */).then(c => c.default || c)
export const LazyCoachTable = import('../..\\components\\Class\\CreateClass\\CoachTable.vue' /* webpackChunkName: "components_Class/CreateClass/CoachTable" */).then(c => c.default || c)
export const LazyCoachTile = import('../..\\components\\Class\\CreateClass\\CoachTile.vue' /* webpackChunkName: "components_Class/CreateClass/CoachTile" */).then(c => c.default || c)
export const LazyFileContainer = import('../..\\components\\Class\\CreateClass\\FileContainer.vue' /* webpackChunkName: "components_Class/CreateClass/FileContainer" */).then(c => c.default || c)
export const LazyUploadFileNew = import('../..\\components\\Class\\CreateClass\\UploadFileNew.vue' /* webpackChunkName: "components_Class/CreateClass/UploadFileNew" */).then(c => c.default || c)
export const LazySportivButton = import('../..\\components\\inputs\\SportivButton\\SportivButton.vue' /* webpackChunkName: "components_inputs/SportivButton/SportivButton" */).then(c => c.default || c)
export const LazySeeAllButton = import('../..\\components\\Navigation\\SeeAllButton\\SeeAllButton.vue' /* webpackChunkName: "components_Navigation/SeeAllButton/SeeAllButton" */).then(c => c.default || c)
export const LazyCreateOrganization = import('../..\\components\\Organization\\Create\\CreateOrganization.vue' /* webpackChunkName: "components_Organization/Create/CreateOrganization" */).then(c => c.default || c)
export const LazyViewMyOrganization = import('../..\\components\\Organization\\View\\ViewMyOrganization.vue' /* webpackChunkName: "components_Organization/View/ViewMyOrganization" */).then(c => c.default || c)
export const LazyStandingTable = import('../..\\components\\Tables\\StandingTable\\StandingTable.vue' /* webpackChunkName: "components_Tables/StandingTable/StandingTable" */).then(c => c.default || c)
export const LazyStandingTableRow = import('../..\\components\\Tables\\StandingTable\\StandingTableRow.vue' /* webpackChunkName: "components_Tables/StandingTable/StandingTableRow" */).then(c => c.default || c)
export const LazyTournamentAllParticipant = import('../..\\components\\TournamentDetail\\TournamentParticipant\\TournamentAllParticipant.vue' /* webpackChunkName: "components_TournamentDetail/TournamentParticipant/TournamentAllParticipant" */).then(c => c.default || c)
export const LazyTournamentParticipantTable = import('../..\\components\\TournamentDetail\\TournamentParticipant\\TournamentParticipantTable.vue' /* webpackChunkName: "components_TournamentDetail/TournamentParticipant/TournamentParticipantTable" */).then(c => c.default || c)
export const LazyTournamentStageParticipantTable = import('../..\\components\\TournamentDetail\\TournamentParticipant\\TournamentStageParticipantTable.vue' /* webpackChunkName: "components_TournamentDetail/TournamentParticipant/TournamentStageParticipantTable" */).then(c => c.default || c)
export const LazyTournamentStage = import('../..\\components\\TournamentDetail\\TournamentStage\\TournamentStage.vue' /* webpackChunkName: "components_TournamentDetail/TournamentStage/TournamentStage" */).then(c => c.default || c)
export const LazyTournamentStageMatch = import('../..\\components\\TournamentDetail\\TournamentStage\\TournamentStageMatch.vue' /* webpackChunkName: "components_TournamentDetail/TournamentStage/TournamentStageMatch" */).then(c => c.default || c)
export const LazyTournamentStageParticipant = import('../..\\components\\TournamentDetail\\TournamentStage\\TournamentStageParticipant.vue' /* webpackChunkName: "components_TournamentDetail/TournamentStage/TournamentStageParticipant" */).then(c => c.default || c)
export const LazyTournamentStageStanding = import('../..\\components\\TournamentDetail\\TournamentStage\\TournamentStageStanding.vue' /* webpackChunkName: "components_TournamentDetail/TournamentStage/TournamentStageStanding" */).then(c => c.default || c)
export const LazyUpdateScheduleModal = import('../..\\components\\Class\\ClassCategory\\Modal\\UpdateScheduleModal.vue' /* webpackChunkName: "components_Class/ClassCategory/Modal/UpdateScheduleModal" */).then(c => c.default || c)
export const LazyViewReviewModal = import('../..\\components\\Class\\ClassCategory\\Modal\\ViewReviewModal.vue' /* webpackChunkName: "components_Class/ClassCategory/Modal/ViewReviewModal" */).then(c => c.default || c)
