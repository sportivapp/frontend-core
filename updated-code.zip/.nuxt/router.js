import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _46576474 = () => interopDefault(import('..\\pages\\about\\index.vue' /* webpackChunkName: "pages/about/index" */))
const _4d565330 = () => interopDefault(import('..\\pages\\booking\\index.vue' /* webpackChunkName: "pages/booking/index" */))
const _4d348da9 = () => interopDefault(import('..\\pages\\class\\index.vue' /* webpackChunkName: "pages/class/index" */))
const _0afd2f7e = () => interopDefault(import('..\\pages\\contact\\index.vue' /* webpackChunkName: "pages/contact/index" */))
const _02a501ea = () => interopDefault(import('..\\pages\\faq\\index.vue' /* webpackChunkName: "pages/faq/index" */))
const _57fa7b88 = () => interopDefault(import('..\\pages\\forgot-password\\index.vue' /* webpackChunkName: "pages/forgot-password/index" */))
const _a3da1340 = () => interopDefault(import('..\\pages\\forum\\index.vue' /* webpackChunkName: "pages/forum/index" */))
const _167631c8 = () => interopDefault(import('..\\pages\\legal\\index.vue' /* webpackChunkName: "pages/legal/index" */))
const _148c112d = () => interopDefault(import('..\\pages\\legal\\index\\lisence&agreement.vue' /* webpackChunkName: "pages/legal/index/lisence&agreement" */))
const _40100642 = () => interopDefault(import('..\\pages\\legal\\index\\privacy-policy.vue' /* webpackChunkName: "pages/legal/index/privacy-policy" */))
const _6b8d3b7b = () => interopDefault(import('..\\pages\\legal\\index\\term-of-services.vue' /* webpackChunkName: "pages/legal/index/term-of-services" */))
const _1c83d718 = () => interopDefault(import('..\\pages\\login\\index.vue' /* webpackChunkName: "pages/login/index" */))
const _6dc112c9 = () => interopDefault(import('..\\pages\\logout\\index.vue' /* webpackChunkName: "pages/logout/index" */))
const _349107c0 = () => interopDefault(import('..\\pages\\news\\index.vue' /* webpackChunkName: "pages/news/index" */))
const _56bae4c0 = () => interopDefault(import('..\\pages\\organization\\index.vue' /* webpackChunkName: "pages/organization/index" */))
const _2aacba12 = () => interopDefault(import('..\\pages\\redirect\\index.vue' /* webpackChunkName: "pages/redirect/index" */))
const _402439d0 = () => interopDefault(import('..\\pages\\register\\index.vue' /* webpackChunkName: "pages/register/index" */))
const _50f24011 = () => interopDefault(import('..\\pages\\setting\\index.vue' /* webpackChunkName: "pages/setting/index" */))
const _49b9e526 = () => interopDefault(import('..\\pages\\setting\\index\\bank-account.vue' /* webpackChunkName: "pages/setting/index/bank-account" */))
const _536f8a56 = () => interopDefault(import('..\\pages\\team\\index.vue' /* webpackChunkName: "pages/team/index" */))
const _b6ce9eec = () => interopDefault(import('..\\pages\\tournament\\index.vue' /* webpackChunkName: "pages/tournament/index" */))
const _7b4c8232 = () => interopDefault(import('..\\pages\\class\\class-form.vue' /* webpackChunkName: "pages/class/class-form" */))
const _278dc2f4 = () => interopDefault(import('..\\pages\\user\\class\\index.vue' /* webpackChunkName: "pages/user/class/index" */))
const _2167e3c7 = () => interopDefault(import('..\\pages\\user\\class\\class-form.vue' /* webpackChunkName: "pages/user/class/class-form" */))
const _b2ab9200 = () => interopDefault(import('..\\pages\\user\\class\\_classId\\index.vue' /* webpackChunkName: "pages/user/class/_classId/index" */))
const _04a134fe = () => interopDefault(import('..\\pages\\user\\class\\_classId\\class-edit.vue' /* webpackChunkName: "pages/user/class/_classId/class-edit" */))
const _981a4b4a = () => interopDefault(import('..\\pages\\user\\class\\_classId\\class-category\\_classCategoryId\\index.vue' /* webpackChunkName: "pages/user/class/_classId/class-category/_classCategoryId/index" */))
const _2f8ee375 = () => interopDefault(import('..\\pages\\class\\_classId\\index.vue' /* webpackChunkName: "pages/class/_classId/index" */))
const _35ed360c = () => interopDefault(import('..\\pages\\news\\_id\\index.vue' /* webpackChunkName: "pages/news/_id/index" */))
const _5d6cb627 = () => interopDefault(import('..\\pages\\tournament\\_tournamentId\\index.vue' /* webpackChunkName: "pages/tournament/_tournamentId/index" */))
const _a7058ba8 = () => interopDefault(import('..\\pages\\class\\_classId\\class-edit.vue' /* webpackChunkName: "pages/class/_classId/class-edit" */))
const _b487ace0 = () => interopDefault(import('..\\pages\\class\\_classId\\class-category\\_classCategoryId\\index.vue' /* webpackChunkName: "pages/class/_classId/class-category/_classCategoryId/index" */))
const _c07c5d66 = () => interopDefault(import('..\\pages\\tournament\\_tournamentId\\match-detail\\_matchId\\index.vue' /* webpackChunkName: "pages/tournament/_tournamentId/match-detail/_matchId/index" */))
const _12a329dc = () => interopDefault(import('..\\pages\\tournament\\_tournamentId\\match-detail\\_matchId\\index\\lineup.vue' /* webpackChunkName: "pages/tournament/_tournamentId/match-detail/_matchId/index/lineup" */))
const _188ab693 = () => interopDefault(import('..\\pages\\tournament\\_tournamentId\\match-detail\\_matchId\\index\\statistic.vue' /* webpackChunkName: "pages/tournament/_tournamentId/match-detail/_matchId/index/statistic" */))
const _227af299 = () => interopDefault(import('..\\pages\\forgot\\_token\\_email\\index.vue' /* webpackChunkName: "pages/forgot/_token/_email/index" */))
const _7b5211da = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _46576474,
    name: "about"
  }, {
    path: "/booking",
    component: _4d565330,
    name: "booking"
  }, {
    path: "/class",
    component: _4d348da9,
    name: "class"
  }, {
    path: "/contact",
    component: _0afd2f7e,
    name: "contact"
  }, {
    path: "/faq",
    component: _02a501ea,
    name: "faq"
  }, {
    path: "/forgot-password",
    component: _57fa7b88,
    name: "forgot-password"
  }, {
    path: "/forum",
    component: _a3da1340,
    name: "forum"
  }, {
    path: "/legal",
    component: _167631c8,
    name: "legal",
    children: [{
      path: "lisence&agreement",
      component: _148c112d,
      name: "legal-index-lisence&agreement"
    }, {
      path: "privacy-policy",
      component: _40100642,
      name: "legal-index-privacy-policy"
    }, {
      path: "term-of-services",
      component: _6b8d3b7b,
      name: "legal-index-term-of-services"
    }]
  }, {
    path: "/login",
    component: _1c83d718,
    name: "login"
  }, {
    path: "/logout",
    component: _6dc112c9,
    name: "logout"
  }, {
    path: "/news",
    component: _349107c0,
    name: "news"
  }, {
    path: "/organization",
    component: _56bae4c0,
    name: "organization"
  }, {
    path: "/redirect",
    component: _2aacba12,
    name: "redirect"
  }, {
    path: "/register",
    component: _402439d0,
    name: "register"
  }, {
    path: "/setting",
    component: _50f24011,
    name: "setting",
    children: [{
      path: "bank-account",
      component: _49b9e526,
      name: "setting-index-bank-account"
    }]
  }, {
    path: "/team",
    component: _536f8a56,
    name: "team"
  }, {
    path: "/tournament",
    component: _b6ce9eec,
    name: "tournament"
  }, {
    path: "/class/class-form",
    component: _7b4c8232,
    name: "class-class-form"
  }, {
    path: "/user/class",
    component: _278dc2f4,
    name: "user-class"
  }, {
    path: "/user/class/class-form",
    component: _2167e3c7,
    name: "user-class-class-form"
  }, {
    path: "/user/class/:classId",
    component: _b2ab9200,
    name: "user-class-classId"
  }, {
    path: "/user/class/:classId/class-edit",
    component: _04a134fe,
    name: "user-class-classId-class-edit"
  }, {
    path: "/user/class/:classId/class-category/:classCategoryId",
    component: _981a4b4a,
    name: "user-class-classId-class-category-classCategoryId"
  }, {
    path: "/class/:classId",
    component: _2f8ee375,
    name: "class-classId"
  }, {
    path: "/news/:id",
    component: _35ed360c,
    name: "news-id"
  }, {
    path: "/tournament/:tournamentId",
    component: _5d6cb627,
    name: "tournament-tournamentId"
  }, {
    path: "/class/:classId/class-edit",
    component: _a7058ba8,
    name: "class-classId-class-edit"
  }, {
    path: "/class/:classId/class-category/:classCategoryId",
    component: _b487ace0,
    name: "class-classId-class-category-classCategoryId"
  }, {
    path: "/tournament/:tournamentId/match-detail/:matchId",
    component: _c07c5d66,
    name: "tournament-tournamentId-match-detail-matchId",
    children: [{
      path: "lineup",
      component: _12a329dc,
      name: "tournament-tournamentId-match-detail-matchId-index-lineup"
    }, {
      path: "statistic",
      component: _188ab693,
      name: "tournament-tournamentId-match-detail-matchId-index-statistic"
    }]
  }, {
    path: "/forgot/:token?/:email",
    component: _227af299,
    name: "forgot-token-email"
  }, {
    path: "/",
    component: _7b5211da,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
