<template>
  <v-container>
    License and Agreement
  </v-container>
</template>

<script>
export default {
  name: 'LicenseAgreement'
}
</script>
